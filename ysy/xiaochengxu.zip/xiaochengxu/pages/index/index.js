//index.js
//获取应用实例
const app = getApp()

Page({
  
  data: {
    
    // text:"2020年冬奥会",
    // desc:"2020年冬奥会向全世界征集开场创意,2020年冬奥会向全世界征集开场创意2020年冬奥会向全世",
    // time:"2018-10-16 15:34",
    navbar:['推荐','头条','娱乐'],
    currentTab:0,
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,

    imgUrlstwo: [
      '/pages/images/swiper/1.jpg',
      '/pages/images/swiper/2.jpg',
      '/pages/images/swiper/3.jpg',
    ],
    indicatorDotstwo: true,
    autoplaytwo: true,
    intervaltwo: 5000,
    durationtwo: 1000
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function(){
    wx.showToast({
      title:'加载中...',
      icon:"loading",
      duration:1000
    })
    
    var that=this;
    console.log(this);
    that.getimg(that);//图片
    that.getNew(that);//新闻
    
  

    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },

  getNew:function(that){
     wx.request({
       url: 'http://127.0.0.1/ten/week1/web/?r=api/news/index',
       success(res){
         that.setData({
           Bnews:res.data.json,
         })
         console.log(res.data.json)
       }
     })
  },
  getimg:function(that){
    wx.request({
      url: 'http://127.0.0.1/ten/week1/web/?r=api/news/manage',
      success(res){
        that.setData({
          imgUrls:res.data.json,
          newsTitles:[1,2,3,4],
        })
        console.log(res.data.json)
      }
    })
    
  },

 
 

  //顶部导航栏
  navbarTap: function (e) {
    this.setData({
      currentTab: e.currentTarget.dataset.idx
    })
  }
})
