// pages/content/content.js
var url_index ="http://127.0.0.1/ten/week1/web/?r=api/news/list";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var that = this;
    wx.showToast({
      title: '加载中...',
      icon: "loading",
      duration: 10000
    }),
      wx.request({
        url: url_index + "&id=" + e.id,
        data: {},
        header: {
          'content-type': 'application/json' // 默认值
        },
        success(res) {
          wx.hideToast();
          that.setData({
            index: res.data.json[0]
          });
          console.log(res.data.json[0])
        }
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})